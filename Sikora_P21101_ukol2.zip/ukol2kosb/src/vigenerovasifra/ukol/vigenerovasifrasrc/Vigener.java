/*
 * Třída metod pro poskytování operací pro Vigenerovu šifru.
 * Šifrování/dešifrování, frekvenční analýzu, index koincidence
*/

package vigenerovasifra.ukol.vigenerovasifrasrc;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class Vigener {

	
	// Zašifruje text pomocí klíčového slova
	
	public static String encrypt(String plaintext, String key) {
		plaintext = format(plaintext);
		key = format(key);
		String ciphertext = "";
		for (int i = 0; i < plaintext.length(); i++) {
			int plainChar = plaintext.charAt(i) - 'A';
			int keyChar = key.charAt(i % key.length()) - 'A';
			int cipherChar = ((plainChar + keyChar) % 26) + 'A';
			ciphertext += (char) cipherChar;
		}		return ciphertext;
	}

	
	 //Dešifruje text pomocí klíčového slova
	
	public static String decrypt(String ciph, String key) {
		ciph = format(ciph);
		key = format(key);
		String plaintext = "";
		for (int i = 0; i < ciph.length(); i++) {
			int ciphChar = ciph.charAt(i) - 'A';
			int keyChar = key.charAt(i % key.length()) - 'A';
			int plainChar = ((ciphChar - keyChar) % 26);
			if (plainChar < 0) {
				plainChar += 26;
			}
			plainChar += 'A';
			plaintext += (char) plainChar;
		}return plaintext;
	}

	
	 // vypočítá četnost písmen každého znaku
	public static int[] letterFrequency(String text) {
		int[] frequency = new int[26];
		text = format(text);
		for (int i = 0; i < text.length(); i++) {
			frequency[text.charAt(i) - 'A']++;
		}return frequency;
	}

	// vyýpočet indexu koincidence z daného textu
	public static double calcIC(String text) {
		return calcIC(letterFrequency(text));
	}

	
	 // výpočet indexu koincidence na základě písmene z frekvenčího pole
	public static double calcIC(int[] frequency) {
		double ic = 0;
		int sum = 0;
		for (int i = 0; i < frequency.length; i++) {
			sum += frequency[i];
		}
		for (int i = 0; i < frequency.length; i++) {
			double top = frequency[i] * (frequency[i] - 1);
			double bottom = sum * (sum - 1);
			ic += top / bottom;
		}return ic;
	}
	// určení délky slova  ze zašifrovaného textu
	public static double estKeyLength(String text) {
		double ic = calcIC(text);
		double top = 0.027 * text.length();
		double bottom = (text.length() - 1) * ic - 0.038 * text.length()
				+ 0.065;
		return top / bottom;
	}

	
	 /*
		Provede kasiskiho test za účelem výpočtu délky klíče ze slova
	 	spoužitého k zašifrování textu. 
		Rozdělí text na s3-znakové podřetezce a počítá počet výskytů a uloží jedinečné výskyty podřetezců do Hasmapy
		Pak se počítají vzdálenosti mezi podřetezci s více výskyty a použijí se k odhadu klíče
	 */
	
	public static int kasiski(String text, int minKeyLength, int maxKeyLength) {
		HashMap<String, Substr> substringMap = new HashMap<String, Substr>();
		text = format(text);
		String sub;

		
		for (int i = 0; i < text.length() - 2; i++) {
			sub = text.substring(i, i + 3);
			if (substringMap.containsKey(sub)) {
				substringMap.get(sub).addOccurance(i);
			} else {
				substringMap.put(sub, new Substr(sub, i));
			}
		}

		
		ArrayList<Substr> substrings = new ArrayList<Substr>(
				substringMap.values());
		// odstrani všechyn pod řetezce s jedinečným výskytem
		substrings = Substr.removeSingleOccurSubs(substrings);
 
		//najde rozdíly mezi pozicemi vice vyskytu stejného podřetezce a vypočita factor
		HashMap<Integer, Integer> factorOcc = new HashMap<Integer, Integer>();
		for (Substr substr : substrings) {
			ArrayList<Integer> differences = substr.getDifferences(true);
			for (Integer diff : differences) {
				ArrayList<Integer> factors = calculateFactors(diff);
			for (Integer fact : factors) {
				if (factorOcc.containsKey(fact)) {
					Integer temp = factorOcc.get(fact);
					factorOcc.put(fact, ++temp);
				} else {
					factorOcc.put(fact, 1);
				}
				}
			}
		}return estimateKeyLength(factorOcc, minKeyLength, maxKeyLength);
	}
	// Stanoví délku slova
	public static int estimateKeyLength(HashMap<Integer, Integer> occurances,
			int minKeyLength, int maxKeyLength) {
		Set<Integer> keys = occurances.keySet();
		Integer maxKey = 0;
		Integer maxFreq = 0;
		for (Integer key : keys) {
			if (key < minKeyLength)
				continue;
			if (key > maxKeyLength)
				continue;
			Integer freq = occurances.get(key);
			if (freq >= maxFreq && key >= minKeyLength && key <= maxKeyLength) {
				maxFreq = freq;
				maxKey = key;
			}
		}
		if (maxKey < minKeyLength) {
			return minKeyLength;
		} else if (maxKey > maxKeyLength) {
			return maxKeyLength;
		} else {
			return maxKey;
		}
	}
	
	public static ArrayList<Integer> calculateFactors(int num) {
		ArrayList<Integer> factors = new ArrayList<Integer>();
		int n = num;
		for (int i = 1; i <= (int) Math.sqrt(n); i++) {
			if (n % i == 0) {
				factors.add(i);
			}
		}
		int size = factors.size();
		for (int i = size - 1; i >= 0; i--) {
			factors.add(num / factors.get(i));
		}

		return factors;
	}

	//metoda, která stanoví odhad klíče
	public static String estimateKey(String ciphertext, int keyLength) {
		String separatedCipher[] = new String[keyLength];
		String key = "";

		for (int i = 0; i < keyLength; i++) {
			separatedCipher[i] = "";
		}

		for (int i = 0; i < ciphertext.length(); i++) {
			separatedCipher[i % keyLength] += ciphertext.charAt(i);
		}

		for (int i = 0; i < keyLength; i++) {
			int[] freq = letterFrequency(separatedCipher[i]);
			key += (char) ((arrayMaxPos(freq) - 4) + 'A');
		}return key;
	}

	public static int arrayMaxPos(int[] theArray) {
		int maxPos = 0;
		for (int i = 1; i < theArray.length; i++) {
			if (theArray[i] > theArray[maxPos]) {
				maxPos = i;
			}
		}		return maxPos;
	}

	
	 //ostrani všechyn neabecedni znaky
	public static String format(String text) {
		return text.toUpperCase().replaceAll("[^\\p{L}]?", "");
	}
}
