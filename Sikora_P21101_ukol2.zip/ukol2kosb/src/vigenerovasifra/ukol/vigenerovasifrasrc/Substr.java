/*
 * Podpurna třída v rámci většího textu. Ukládá hodnotu
 * podřetězec a také pozice všech výskytů 
 * v rámci většího textu. Metody využiti převážne v kryptografické části
 */

package vigenerovasifra.ukol.vigenerovasifrasrc;
import java.util.ArrayList;
import java.util.Iterator;

public class Substr {

	private String message;
	private ArrayList<Integer> position;
	private ArrayList<Integer> difference;
	
	public Substr(String msg, int pos) {
		message = msg;
		position = new ArrayList<Integer>();
		difference = new ArrayList<Integer>();
		position.add(pos);
	}

	// přidává výskyt znak u do pole
	public void addOccurance(int pos) {
		position.add(pos);
	}

// Vypočítá a uloží vzdálenosti mezi pozicemi
	public void calculateDifferences() {
		if (position.size() > 1) {
			for (int i = 1; i < position.size(); i++) {
				difference.add(position.get(i) - position.get(i - 1));
			}
		} else {
			difference.add(0);
		}
	}

// vráti pozice 
	public ArrayList<Integer> getPositions() {
		ArrayList<Integer> pos = new ArrayList<Integer>();
		for (Integer n : position) {
			pos.add(n);
		}return pos;
	}
	
/* Vrátí ArrayList všech rozdílů mezi následujícími
* výskyty vypočítaných znaků  pomocí  calculateDifferences. 
*/
	public ArrayList<Integer> getDifferences(boolean recalc) {
		if (recalc) {
			calculateDifferences();
		}
		ArrayList<Integer> diff = new ArrayList<Integer>();
		for (Integer n : difference) {
			diff.add(n);
		}return diff;
	}
	 //vrací počet vyskytu v podřetezci
	public int getOccuranceCount() {
		return position.size();
	}

	
	 //Ověří zda je více než 1 výskyt
	
	public boolean isSingleOccurance() {
		return position.size() <= 1;
	}
	//Vratí zprávu
	
	public String getValue() {
		return message;
	}

	// odstranbní jednotlivé výskyty
	public static ArrayList<Substr> removeSingleOccurSubs(
			ArrayList<Substr> subs) {
		Iterator<Substr> it = subs.iterator();
		while (it.hasNext()) {
			Substr substr = it.next();
			if (substr.isSingleOccurance()) {
				it.remove();
			}
		}
		return subs;
	}

	// vrátí řetezec spolu s pozici každého výskytu
		public String toString() {
		String out = message + ": ";
		for (int i = 0; i < position.size(); i++) {
			out += position.get(i) + ", ";
		}
		return out;
	}
}
